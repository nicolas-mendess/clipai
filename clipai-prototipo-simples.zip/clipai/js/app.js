// ClipAI: interações básicas do protótipo.
const botaoTema = document.querySelector('#tema');
const painelAcessibilidade = document.querySelector('#painel-acessibilidade');

// Alterna entre o tema escuro e o tema claro.
botaoTema.addEventListener('click', () => {
  document.body.classList.toggle('tema-claro');
  botaoTema.textContent = document.body.classList.contains('tema-claro') ? '☾ Tema' : '☼ Tema';
});

// Abre e fecha as opções de acessibilidade.
document.querySelector('#acessibilidade').addEventListener('click', () => {
  painelAcessibilidade.hidden = false;
});
document.querySelector('#fechar-acessibilidade').addEventListener('click', () => {
  painelAcessibilidade.hidden = true;
});

// Ajusta o tamanho do texto na página.
let tamanhoFonte = 1;
document.querySelector('#aumentar-fonte').addEventListener('click', () => {
  tamanhoFonte = Math.min(1.2, tamanhoFonte + 0.1);
  document.documentElement.style.setProperty('--fonte', tamanhoFonte);
});
document.querySelector('#diminuir-fonte').addEventListener('click', () => {
  tamanhoFonte = Math.max(0.9, tamanhoFonte - 0.1);
  document.documentElement.style.setProperty('--fonte', tamanhoFonte);
});
document.querySelector('#contraste').addEventListener('click', (evento) => {
  const ativo = document.body.classList.toggle('alto-contraste');
  evento.currentTarget.setAttribute('aria-pressed', String(ativo));
});

// Mostra o nome do arquivo escolhido. O vídeo não é enviado nem processado.
document.querySelector('#arquivo-video').addEventListener('change', (evento) => {
  const arquivo = evento.target.files[0];
  document.querySelector('#nome-arquivo').textContent = arquivo
    ? `Arquivo selecionado: ${arquivo.name}`
    : 'Nenhum arquivo selecionado. O protótipo apenas identifica o arquivo; não envia nem processa o vídeo.';
});

// Simula a criação de um projeto e informa que esta versão é demonstrativa.
document.querySelector('#form-projeto').addEventListener('submit', (evento) => {
  evento.preventDefault();
  const nome = document.querySelector('#nome-projeto').value.trim();
  const arquivo = document.querySelector('#arquivo-video').files[0];
  const link = document.querySelector('#link-video').value.trim();
  const instrucoes = document.querySelector('#instrucoes').value.trim();
  if (!arquivo && !link) {
    document.querySelector('#mensagem-projeto').textContent = 'Escolha um arquivo ou informe um link para continuar.';
    return;
  }
  if (!instrucoes) {
    document.querySelector('#mensagem-projeto').textContent = 'Escreva as instruções para os cortes.';
    return;
  }
  document.querySelector('#mensagem-projeto').textContent = `Projeto “${nome}” preenchido! A geração de cortes é apenas demonstrativa nesta versão.`;
});

// Pesquisa os cartões de cortes pelo título.
document.querySelector('#pesquisa').addEventListener('input', (evento) => {
  const termo = evento.target.value.toLocaleLowerCase('pt-BR');
  let encontrados = 0;
  document.querySelectorAll('.cartao-corte').forEach((cartao) => {
    const corresponde = cartao.dataset.nome.toLocaleLowerCase('pt-BR').includes(termo);
    cartao.hidden = !corresponde;
    if (corresponde) encontrados++;
  });
  document.querySelector('#sem-resultados').hidden = encontrados > 0;
});

// Move o carrossel horizontalmente para mostrar os outros cartões.
const carrossel = document.querySelector('#carrossel');
document.querySelector('#anterior').addEventListener('click', () => {
  carrossel.scrollBy({ left: -270, behavior: 'smooth' });
});
document.querySelector('#proximo').addEventListener('click', () => {
  carrossel.scrollBy({ left: 270, behavior: 'smooth' });
});

// Formulário local de demonstração: não envia dados para um servidor.
document.querySelector('#form-contato').addEventListener('submit', (evento) => {
  evento.preventDefault();
  document.querySelector('#mensagem-contato').textContent = 'Mensagem registrada apenas nesta demonstração. Nenhum dado foi enviado.';
  evento.target.reset();
});
