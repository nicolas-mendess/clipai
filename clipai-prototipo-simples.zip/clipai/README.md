# ClipAI — Protótipo simples

## 1. Sobre o projeto
O ClipAI é um protótipo de interface para uma plataforma que ajudaria o usuário a organizar vídeos longos e planejar cortes curtos para redes sociais. Esta versão foi feita com HTML, CSS e JavaScript puro, priorizando simplicidade e facilidade de apresentação.

**Importante:** o projeto ainda não usa inteligência artificial e não corta ou processa vídeos. O formulário de projeto apenas valida os campos e mostra uma mensagem demonstrativa. O campo de arquivo apenas exibe o nome do vídeo escolhido no computador.

## 2. Como executar
1. Baixe e extraia a pasta `clipai`.
2. Abra `index.html` em um navegador. Também é possível abrir a pasta no Visual Studio Code e usar a extensão Live Server.
3. Não é necessário instalar bibliotecas ou frameworks.

## 3. Estrutura dos arquivos
- `index.html`: conteúdo e estrutura de todas as seções do site.
- `css/styles.css`: cores, fontes, espaçamentos, cartões e adaptação para telas menores.
- `js/app.js`: interações simples, como tema, acessibilidade, pesquisa, carrossel e formulários.

## 4. Descrição detalhada das partes fundamentais

### 4.1 Cabeçalho e navegação
O cabeçalho fica no topo da página e apresenta a marca ClipAI e links para as seções principais: Início, Como funciona, Novo projeto, Meus cortes e Contato. Os links usam âncoras HTML, por isso levam diretamente à parte correspondente da mesma página. Ao lado ficam os botões de tema e acessibilidade.

### 4.2 Seção inicial (Início)
É a primeira área que o visitante vê. Apresenta o nome do produto, uma frase que resume sua finalidade, um pequeno texto explicativo e o botão “Criar meu projeto”. A ilustração representa visualmente um editor de vídeo, sem depender de imagens externas.

### 4.3 Visão geral
Mostra três cartões com números ilustrativos: quantidade de projetos, cortes planejados e tempo estimado economizado. Os cartões ajudam a demonstrar como uma futura plataforma poderia resumir a atividade do usuário. Os números são exemplos, não dados reais.

### 4.4 Como funciona
Apresenta o fluxo de uso em três cartões: adicionar um vídeo, escrever instruções e organizar os cortes. Essa seção explica o objetivo do site mesmo para quem está acessando pela primeira vez.

### 4.5 Formulário “Criar novo projeto”
É a principal área interativa. O usuário informa um nome, pode escolher um arquivo de vídeo ou inserir um link, escreve o tipo de trecho que procura e seleciona o formato desejado. O JavaScript verifica se existe um arquivo ou link e se as instruções foram preenchidas. Depois mostra uma mensagem para confirmar que o formulário foi preenchido.

Nesta versão, o arquivo não é enviado para a internet e o link não é analisado. A seleção de formato também é apenas visual. A geração real de cortes exigiria um backend e ferramentas de processamento de vídeo, que não fazem parte deste protótipo.

### 4.6 Meus cortes
A biblioteca apresenta três cartões fictícios. Cada cartão tem uma miniatura ilustrativa, duração de exemplo, título, nome do projeto e indicação de que é um exemplo. O campo de pesquisa filtra os cartões pelo título enquanto o usuário digita. Se nenhum título corresponder, aparece uma mensagem informativa.

### 4.7 Carrossel de ideias
O carrossel contém cartões com sugestões de temas para orientar os cortes: momentos engraçados, dicas, frases marcantes e melhores momentos. Os botões “Anterior” e “Próximo” deslocam horizontalmente a lista de cartões.

### 4.8 Formulário de contato
Solicita nome, e-mail e mensagem. Ao enviar, o navegador impede o recarregamento da página e apresenta uma confirmação demonstrativa. Não existe envio real de e-mail nem armazenamento das informações.

### 4.9 Tema claro e escuro
O botão “Tema” alterna as variáveis de cores da página. O tema escuro é o padrão. O tema claro facilita a visualização em ambientes iluminados. A troca é feita por uma classe CSS aplicada ao elemento `body`.

### 4.10 Acessibilidade
O painel apresenta controles para aumentar ou diminuir o tamanho do texto e ativar alto contraste. Os controles são implementados com JavaScript simples. O HTML usa títulos em ordem, rótulos associados aos campos, botões identificados e mensagens de estado. O CSS também inclui adaptação para telas menores e respeita a preferência do sistema por redução de movimento.

### 4.11 Rodapé
O rodapé identifica o projeto, explica que se trata de um protótipo acadêmico e repete links importantes para facilitar a navegação.

## 5. Identidade visual e cores
A paleta utiliza fundo escuro (`#10111b`), superfícies em tom grafite (`#1b1d2b`), roxo (`#7955e8`) e verde-água (`#43d6bd`). O grafite cria uma base visual discreta; o roxo destaca ações principais e sugere criatividade; o verde-água é usado em detalhes para destacar informações. O tema claro oferece uma alternativa com fundo branco e texto escuro.

A escolha final das cores deve ser acompanhada de uma verificação de contraste entre texto e fundo, seguindo as recomendações WCAG. O protótipo adota textos legíveis, rótulos e controles identificáveis, mas a conformidade completa deve ser confirmada com testes de acessibilidade.

## 6. Tecnologias
- HTML5: estrutura e conteúdo.
- CSS3: aparência, cores e responsividade.
- JavaScript: interações do protótipo.

## 7. Limitações e melhorias futuras
- Criar processamento real de vídeo.
- Integrar uma ferramenta de transcrição e análise de conteúdo.
- Salvar projetos e cortes em banco de dados.
- Permitir edição, pré-visualização e download dos cortes reais.
- Realizar testes de contraste e navegação por teclado com ferramentas de acessibilidade.

## 8. Relação com os requisitos do projeto acadêmico
O protótipo contém cartões, campo de pesquisa, formulário de contato, carrossel, elementos visuais, cartões explicativos, alternância de tema, rodapé e controles básicos de acessibilidade. A Parte C, questão 1, do enunciado solicita uma redação sem uso de IA; essa parte deve ser escrita pelo estudante com suas próprias palavras.
